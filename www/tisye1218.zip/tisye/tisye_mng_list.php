<?php
//tisye mng list.php
error_reporting(E_ALL ^ E_NOTICE);
parse_str($_SERVER['QUERY_STRING'], $parr);
//print_r($parr);

$db_cfg = array(
    'host' => '65.49.145.72',
    'db' => 'postgres',
    'db_user' => 'postgres',
    'db_pwd' => 'woaitav1314',
);
$pdo = new PDO("pgsql:host=" . $db_cfg['host'] . ";port=5432;dbname=" . $db_cfg['db'], $db_cfg['db_user'], $db_cfg['db_pwd']); //创建一个pdo对象
$pdo->exec("set names 'utf8'");
 

$cur_loginacc=$_COOKIE['loginacc'];
$sql =<<<EOF
select * from tisye提现表 where uname='$cur_loginacc' order by id desc limit 200;
EOF;

$glb['sql']=$sql;
//print_r($glb);
$sth = $pdo->query($sql);
$rows = $sth->fetchAll();

echo json_encode($rows);

