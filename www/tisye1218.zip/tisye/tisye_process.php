<?php
error_reporting(E_ALL ^ E_NOTICE);

$mysql_conf = array(
    'host' => '65.49.145.72',
    'db' => 'postgres',
    'db_user' => 'postgres',
    'db_pwd' => 'woaitav1314',
);
$pdo = new PDO("pgsql:host=" . $mysql_conf['host'] . ";port=5432;dbname=" . $mysql_conf['db'], $mysql_conf['db_user'], $mysql_conf['db_pwd']); //创建一个pdo对象
$pdo->exec("set names 'utf8'");
$sql = "select * from user where name = ?";

//sprintf("%s love %s.", "a","b");
// use exec() because no results are returned
$sql = "update tisye提现表  set stat状态='已经处理' where id=%s and uname='%s'"; // .;
$sql = sprintf($sql, $_GET['id'], $_COOKIE['loginacc']);

//print_r($_GET);

print_r($sql);
//print_r($pdo);
//try{

$pdo->exec($sql);
echo " successfully";
