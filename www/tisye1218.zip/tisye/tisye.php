<?php
error_reporting(E_ALL ^ E_NOTICE);

try {
    parse_str($_SERVER['QUERY_STRING'], $parr);
    print_r($parr);

    $json_str = json_encode($parr);
    file_put_contents("C:\\data\\tisyi\\" . time(), $json_str);
    print('ok');
// echo "Hello world!<br>";
    $aa = 333;
} catch (Exception $e) {

}

$mysql_conf = array(
    'host' => '65.49.145.72',
    'db' => 'postgres',
    'db_user' => 'postgres',
    'db_pwd' => 'woaitav1314',
);
$pdo = new PDO("pgsql:host=" . $mysql_conf['host'] . ";port=5432;dbname=" . $mysql_conf['db'], $mysql_conf['db_user'], $mysql_conf['db_pwd']); //创建一个pdo对象
$pdo->exec("set names 'utf8'");
$sql = "select * from user where name = ?";

try {

    $pdo->beginTransaction();
    $sql = " UPDATE merchan   SET  available_balance = available_balance-%s   where uname='" . $_COOKIE['loginacc'] . "'";
    $sql = sprintf($sql, $_GET['amt金额']);
    $glb['sql_up mer bls'] = $sql;
    $pdo->exec($sql);

//sprintf("%s love %s.", "a","b");
    // use exec() because no results are returned
    $sql = "INSERT INTO tisye提现表 (org开户机构, acc账户, name名字,amt金额,uname)VALUES ('%s', '%s', '%s','%s','%s') ";
    print_r($_GET);
    $sql = sprintf($sql, $_GET['org开户机构'] . "(" . $_GET['brach网点名称'] . ")", $_GET['acc'], $_GET['name'], $_GET['amt金额'],$_COOKIE['loginacc']);
    print_r($sql);
    print_r($pdo);
//try{
    $pdo->exec($sql);
    $pdo->commit();

} catch (Exception $e) {
    $pdo->rollBack();
    echo "Failed: " . $e->getMessage();
    return;
}

echo "New record created successfully";
print_r($glb);

// }
// catch(PDOException $e)
//     {
//     echo $sql . "<br>" . $e->getMessage();
//     }
