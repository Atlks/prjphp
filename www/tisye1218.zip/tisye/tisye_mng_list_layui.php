<?php
//tisye mng list.php
error_reporting(E_ALL ^ E_NOTICE);
parse_str($_SERVER['QUERY_STRING'], $parr);
//print_r($parr);

$db_cfg = array(
    'host' => '65.49.145.72',
    'db' => 'postgres',
    'db_user' => 'postgres',
    'db_pwd' => 'woaitav1314',
);
$pdo = new PDO("pgsql:host=" . $db_cfg['host'] . ";port=5432;dbname=" . $db_cfg['db'], $db_cfg['db_user'], $db_cfg['db_pwd']); //创建一个pdo对象
$pdo->exec("set names 'utf8'");
 

$cur_loginacc=$_COOKIE['loginacc'];

$lmt=$_GET['limit'];
$offset =($_GET['page']-1)*$lmt;


$sql =<<<EOF
select * from tisye提现表 where uname='$cur_loginacc' ;
EOF;
$count=count( $pdo->query($sql)->fetchAll());

$sql =<<<EOF
select * from tisye提现表 where uname='$cur_loginacc' order by id desc limit $lmt offset $offset ;
EOF;

$glb['sql']=$sql;
//print_r($glb);
$sth = $pdo->query($sql);
$rows = $sth->fetchAll();
$rzt['data']=$rows;
$rzt['code']=0;
$rzt['count']=$count;
echo json_encode($rzt);

